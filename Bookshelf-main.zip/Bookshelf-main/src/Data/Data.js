export const Data = [
  {
    img:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/To_Kill_a_Mockingbird_%28first_edition_cover%29.jpg/330px-To_Kill_a_Mockingbird_%28first_edition_cover%29.jpg",
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    status: "Read"
  },
  {
    img:
      "https://images-eu.ssl-images-amazon.com/images/I/61fo4siBqRL._AC_UL210_SR210,210_.jpg",
    title: " India 1984",
    author: "George Orwell",
    status: "Read"
  },
  {
    img:
      "https://m.media-amazon.com/images/I/819HSIKiWdS._AC_UF1000,1000_QL80_.jpg",
    title: "Pride and Prejudice",
    author: "Jane Austen",
    status: "Currently Reading"
  },
  {
    img:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/The_Great_Gatsby_Cover_1925_Retouched.jpg/330px-The_Great_Gatsby_Cover_1925_Retouched.jpg",
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    status: "none"
  },
  {
    img:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFyPQk7DDKwqhRTX0i79HKxe8AvkWEbKbXrg&usqp=CAU",
    title: " A Brief  of Humankind",
    author: "Yuval Noah Harari",
    status: "Currently Reading"
  },
  {
    img:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/The_Catcher_In_The_Rye_%2814353822692%29.jpg/1200px-The_Catcher_In_The_Rye_%2814353822692%29.jpg?20170326210040",
    title: "The Catcher in the Rye",
    author: "J.D. Salinger",
    status: "Currently Reading"
  },
  {
    img:
      "https://m.media-amazon.com/images/M/MV5BN2EyZjM3NzUtNWUzMi00MTgxLWI0NTctMzY4M2VlOTdjZWRiXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_.jpg",
    title: "The Lord of the Rings",
    author: "J.R.R. Tolkien",
    status: "Want to Read"
  },
  {
    img:
      "https://m.media-amazon.com/images/I/81ym3QUd3KL._AC_UF1000,1000_QL80_.jpg",
    title: "Dune",
    author: "Frank Herbert",
    status: "Want to Read"
  }
];
